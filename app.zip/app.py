import os
import sys
import tempfile
from PyQt6.QtCore import Qt, QUrl
from PyQt6.QtWidgets import (
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)
from PyQt6.QtWebEngineCore import QWebEngineSettings
from PyQt6.QtWebEngineWidgets import QWebEngineView
import folium
import geopandas as gpd


class VentanaPrincipal(QMainWindow):

  def __init__(self):
    super().__init__()
    self.setWindowTitle(
        "GeoRoute Express - Gestor de Rutas, Manzanas y Portales (DHL Style)"
    )
    self.setGeometry(100, 100, 1200, 750)

    self.gdf_manzanas = None
    self.gdf_portales = None
    self.archivo_cargado = None
    self.columna_cp_portales = None
    self.columna_cp_manzanas = None

    # Widget central y layout principal
    self.widget_central = QWidget()
    self.setCentralWidget(self.widget_central)
    layout_principal = QHBoxLayout(self.widget_central)

    # --- PANEL IZQUIERDO ---
    layout_izquierdo = QVBoxLayout()

    # 1. Botón de carga (Rojo DHL: #D40511)
    self.btn_cargar = QPushButton("📁 Cargar Archivo GPKG")
    self.btn_cargar.setStyleSheet(
        "padding: 10px; font-weight: bold; background-color: #D40511; color:"
        " white; border-radius: 5px;"
    )
    self.btn_cargar.clicked.connect(self.cargar_gpkg)
    layout_izquierdo.addWidget(self.btn_cargar)

    # 2. Sección de selección múltiple de Códigos Postales / Zonas
    layout_filtro = QVBoxLayout()
    layout_filtro.addWidget(
        QLabel("<b>Seleccionar Códigos Postales / Zonas (Multiselección):</b>")
    )

    # Botón secundario para limpiar selecciones rápidamente
    self.btn_limpiar = QPushButton("🧹 Dejar en blanco / Desmarcar todo")
    self.btn_limpiar.setStyleSheet(
        "padding: 5px; background-color: #555555; color: white; border-radius:"
        " 3px; font-size: 11px;"
    )
    self.btn_limpiar.setEnabled(False)
    self.btn_limpiar.clicked.connect(self.desmarcar_todo)
    layout_filtro.addWidget(self.btn_limpiar)

    self.lista_cp = QListWidget()
    self.lista_cp.setEnabled(False)
    layout_filtro.addWidget(self.lista_cp)

    # Botón de acción principal con acento Amarillo/Rojo DHL
    self.btn_filtrar = QPushButton("🗺️ Filtrar y Sumar Zonas Seleccionadas")
    self.btn_filtrar.setStyleSheet(
        "padding: 10px; font-weight: bold; background-color: #FFCC00; color:"
        " #D40511; border: 2px solid #D40511; border-radius: 5px;"
    )
    self.btn_filtrar.setEnabled(False)
    self.btn_filtrar.clicked.connect(self.filtrar_y_dibujar_por_cp)
    layout_filtro.addWidget(self.btn_filtrar)

    layout_izquierdo.addLayout(layout_filtro)

    # 3. Consola
    self.consola = QTextEdit()
    self.consola.setReadOnly(True)
    self.consola.setPlaceholderText(
        "Aquí aparecerá el registro de actividad..."
    )
    layout_izquierdo.addWidget(self.consola)

    layout_principal.addLayout(layout_izquierdo, stretch=1)

    # --- PANEL DERECHO (Mapa) ---
    self.browser_mapa = QWebEngineView()
    settings = self.browser_mapa.page().settings()
    settings.setAttribute(
        QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True
    )
    settings.setAttribute(
        QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True
    )
    layout_principal.addWidget(self.browser_mapa, stretch=2)

    self.consola.append(
        "Aplicación iniciada correctamente. Cargue un archivo GPKG para comenzar."
    )
    self.mostrar_mapa_base(37.8, -1.1, 7)

  def mostrar_mapa_base(self, lat, lon, zoom):
    mapa = folium.Map(location=[lat, lon], zoom_start=zoom, tiles="OpenStreetMap")
    datos_temp = tempfile.gettempdir()
    self.ruta_html_temp = os.path.join(datos_temp, "mapa_temp.html")
    mapa.save(self.ruta_html_temp)
    self.browser_mapa.setUrl(QUrl.fromLocalFile(self.ruta_html_temp))

  def cargar_gpkg(self):
    archivo, _ = QFileDialog.getOpenFileName(
        self, "Seleccionar archivo GeoPackage", "", "Archivos GPKG (*.gpkg)"
    )

    if archivo:
      self.archivo_cargado = archivo
      self.consola.append(f"\nArchivo seleccionado: {os.path.basename(archivo)}")
      try:
        self.gdf_manzanas = gpd.read_file(archivo, layer="manzana")
        self.gdf_portales = gpd.read_file(archivo, layer="portalpk_publi")

        self.consola.append(
            f"-> Capa 'manzana' cargada: {len(self.gdf_manzanas)} registros."
        )
        self.consola.append(
            f"-> Capa 'portalpk_publi' cargada: {len(self.gdf_portales)}"
            " registros."
        )

        posibles_nombres = [
            "postal",
            "cp",
            "codigo_postal",
            "postal_code",
            "c_postal",
            "cod_postal",
        ]

        # 1. Buscar columna de CP en Portales
        self.columna_cp_portales = None
        if self.gdf_portales is not None and not self.gdf_portales.empty:
          for col in posibles_nombres:
            for c_real in self.gdf_portales.columns:
              if col in c_real.lower():
                self.columna_cp_portales = c_real
                break
            if self.columna_cp_portales:
              break

        # 2. Buscar columna de CP en Manzanas
        self.columna_cp_manzanas = None
        if self.gdf_manzanas is not None and not self.gdf_manzanas.empty:
          for col in posibles_nombres:
            for c_real in self.gdf_manzanas.columns:
              if col in c_real.lower():
                self.columna_cp_manzanas = c_real
                break
            if self.columna_cp_manzanas:
              break

          if not self.columna_cp_manzanas:
            for col in ["ine_mun", "id_manz"]:
              if col in self.gdf_manzanas.columns:
                self.columna_cp_manzanas = col
                break

        # --- EXTRACCIÓN COMBINADA (Portales + Manzanas) PARA QUE NO PASE POR ALTO NINGÚN CP ---
        codigos_set = set()

        # Recoger de portales si existe la columna
        if self.gdf_portales is not None and self.columna_cp_portales:
          for val in self.gdf_portales[self.columna_cp_portales].dropna():
            val_str = str(val).strip()
            if val_str.endswith(".0"):
              val_str = val_str[:-2]
            if (
                val_str
                and val_str.lower() not in ["none", "nan", "nat", ""]
                and val_str != "0"
            ):
              codigos_set.add(val_str)

        # Recoger de manzanas por si acaso el CP está ahí y no en el portal (caso típico CartoCiudad)
        if self.gdf_manzanas is not None and self.columna_cp_manzanas:
          for val in self.gdf_manzanas[self.columna_cp_manzanas].dropna():
            val_str = str(val).strip()
            if val_str.endswith(".0"):
              val_str = val_str[:-2]
            if (
                val_str
                and val_str.lower() not in ["none", "nan", "nat", ""]
                and val_str != "0"
            ):
              codigos_set.add(val_str)

        codigos_unicos = sorted(list(codigos_set))

        if codigos_unicos:
          self.lista_cp.blockSignals(True)
          self.lista_cp.clear()
          for cp in codigos_unicos:
            item = QListWidgetItem(cp)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            self.lista_cp.addItem(item)
          self.lista_cp.blockSignals(False)

          self.lista_cp.setEnabled(True)
          self.btn_limpiar.setEnabled(True)
          self.btn_filtrar.setEnabled(True)
          self.consola.append(
              f"✅ Se han cargado {len(codigos_unicos)} códigos postales únicos"
              " (combinando portales y manzanas)."
          )

          if "30386" in codigos_unicos:
            self.consola.append(
                "📌 ¡El código postal 30386 ha sido encontrado y cargado"
                " correctamente!"
            )
          else:
            self.consola.append(
                "⚠️ Nota: El código '30386' sigue sin aparecer en este archivo"
                " de CartoCiudad Murcia."
            )
        else:
          self.consola.append(
              "⚠️ No se encontraron códigos postales en las capas del GPKG."
          )

      except Exception as e:
        self.consola.append(f"❌ Error al leer el GPKG: {str(e)}")

  def desmarcar_todo(self):
    """Desmarca todas las casillas de la lista de códigos postales."""
    self.lista_cp.blockSignals(True)
    for i in range(self.lista_cp.count()):
      item = self.lista_cp.item(i)
      item.setCheckState(Qt.CheckState.Unchecked)
    self.lista_cp.blockSignals(False)
    self.consola.append("🧹 Selección limpiada: todas las casillas desmarcadas.")

  def filtrar_y_dibujar_por_cp(self):
    if self.gdf_portales is None:
      return

    cps_seleccionados = []
    for i in range(self.lista_cp.count()):
      item = self.lista_cp.item(i)
      if item.checkState() == Qt.CheckState.Checked:
        cps_seleccionados.append(item.text())

    if not cps_seleccionados:
      self.consola.append(
          "⚠️ Por favor, seleccione al menos un código postal de la lista."
      )
      return

    self.consola.append(
        "\n--- Filtrando zonas seleccionadas ---"
        f"\nZonas: {', '.join(cps_seleccionados)}"
    )

    try:
      portales_filtrados = None
      if (
          self.gdf_portales is not None
          and not self.gdf_portales.empty
          and self.columna_cp_portales
      ):
        mask_port = (
            self.gdf_portales[self.columna_cp_portales]
            .astype(str)
            .str.strip()
            .isin(cps_seleccionados)
        )
        portales_filtrados = self.gdf_portales[mask_port]

      manzanas_filtradas = None
      if (
          self.gdf_manzanas is not None
          and not self.gdf_manzanas.empty
          and self.columna_cp_manzanas
          and self.columna_cp_manzanas == self.columna_cp_portales
      ):
        mask_manz = (
            self.gdf_manzanas[self.columna_cp_manzanas]
            .astype(str)
            .str.strip()
            .isin(cps_seleccionados)
        )
        manzanas_filtradas = self.gdf_manzanas[mask_manz]

      total_portales = (
          len(portales_filtrados) if portales_filtrados is not None else 0
      )
      total_manzanas = (
          len(manzanas_filtradas) if manzanas_filtradas is not None else 0
      )

      self.consola.append(
          f"📊 Resumen de selección:\n  • Zonas activas: {len(cps_seleccionados)}"
          f"\n  • Total portales sumados: {total_portales}\n  • Total manzanas"
          f" asociadas: {total_manzanas}"
      )

      if total_portales == 0 and total_manzanas == 0:
        self.consola.append(
            "❌ No hay elementos asociados a las zonas seleccionadas."
        )
        return

      # --- OPTIMIZACIÓN AMPLIADA PARA PORTALES ---
      # Elevamos el límite seguro a 12,000 portales para aprovechar la capacidad de renderizado rápido
      limite_portales = 12000
      if total_portales > limite_portales:
        portales_filtrados = portales_filtrados.head(limite_portales)
        self.consola.append(
            f"⚡ Límite ampliado: Mostrando una muestra optimizada de"
            f" {limite_portales} portales de los {total_portales} totales."
        )

      if total_manzanas > 2500:
        manzanas_filtradas = manzanas_filtradas.head(2500)

      self.dibujar_capas_en_mapa(
          manzanas_filtradas,
          portales_filtrados,
          f"Zonas: {', '.join(cps_seleccionados)}",
      )

    except Exception as e:
      self.consola.append(f"❌ Error al filtrar los datos: {str(e)}")

  def dibujar_capas_en_mapa(
      self, gdf_manzanas_sub, gdf_portales_sub, titulo_capa
  ):
    try:
      if gdf_manzanas_sub is not None and not gdf_manzanas_sub.empty:
        gdf_m_wgs = gdf_manzanas_sub.to_crs(epsg=4326)
        cols_m = list(
            dict.fromkeys(
                [
                    col
                    for col in [
                        self.columna_cp_manzanas,
                        "id_manz",
                        "ine_mun",
                        "geometry",
                    ]
                    if col in gdf_m_wgs.columns
                ]
            )
        )
        gdf_m_wgs = gdf_m_wgs[cols_m]
      else:
        gdf_m_wgs = None

      if gdf_portales_sub is not None and not gdf_portales_sub.empty:
        gdf_p_wgs = gdf_portales_sub.to_crs(epsg=4326)
      else:
        gdf_p_wgs = None

      if gdf_p_wgs is not None and not gdf_p_wgs.empty:
        centroide_global = gdf_p_wgs.geometry.union_all().centroid
      elif gdf_m_wgs is not None and not gdf_m_wgs.empty:
        centroide_global = gdf_m_wgs.geometry.union_all().centroid
      else:
        return

      lat_centro = centroide_global.y
      lon_centro = centroide_global.x

      mapa = folium.Map(
          location=[lat_centro, lon_centro], zoom_start=14, tiles="OpenStreetMap"
      )

      if gdf_m_wgs is not None and not gdf_m_wgs.empty:
        fields_tooltip = []
        aliases_tooltip = []
        for col in [self.columna_cp_manzanas, "id_manz", "ine_mun"]:
          if col in gdf_m_wgs.columns and col not in fields_tooltip:
            fields_tooltip.append(col)
            aliases_tooltip.append(f"{col.upper()}:")

        folium.GeoJson(
            gdf_m_wgs,
            name="Manzanas",
            style_function=lambda x: {
                "fillColor": "#FFCC00",
                "color": "#D40511",
                "weight": 2,
                "fillOpacity": 0.25,
            },
            tooltip=(
                folium.GeoJsonTooltip(
                    fields=fields_tooltip,
                    aliases=aliases_tooltip,
                    localize=True,
                )
                if fields_tooltip
                else None
            ),
        ).add_to(mapa)

      # --- OPTIMIZACIÓN VISUAL DE MARCADORES (Fast Marker Rendering) ---
      # Si hay más de 2000 portales, utilizamos CircleMarker optimizados sin popups masivos individuales
      # o con estilos más ligeros para garantizar fluidez inmediata en el navegador.
      if gdf_p_wgs is not None and not gdf_p_wgs.empty:
        for idx, row in gdf_p_wgs.iterrows():
          pt = row.geometry
          if pt and not pt.is_empty:
            folium.CircleMarker(
                location=[pt.y, pt.x],
                radius=2.5,  # Ligeramente más pequeño para aglomeraciones densas
                color="#D40511",
                fill=True,
                fill_color="#FFCC00",
                fill_opacity=0.85,
                weight=1,
                popup=f"Portal ID: {row.get('id_portal', 'N/D')} - CP: {row.get(self.columna_cp_portales, 'N/D')}",
            ).add_to(mapa)

      mapa.save(self.ruta_html_temp)
      self.browser_mapa.setUrl(QUrl.fromLocalFile(self.ruta_html_temp))
      self.consola.append(
          f"🗺️ Mapa actualizado correctamente con alta densidad de portales."
      )

    except Exception as e:
      self.consola.append(f"❌ Error al renderizar el mapa: {str(e)}")


if __name__ == "__main__":
  app = QApplication(sys.argv)
  ventana = VentanaPrincipal()
  ventana.show()
  sys.exit(app.exec())